import { createStore, combineReducers, compose } from 'redux';
import firebase from 'firebase';
import 'firebase/firestore';
import { reactReduxFirebase, firebaseReducer } from 'react-redux-firebase';
import { reduxFirestore, firestoreReducer } from 'redux-firestore';
import { composeWithDevTools } from 'redux-devtools-extension';
//Reducers
import notifyReducer from './reducers/notifyReducer';
import settingsReducers from './reducers/settingsReducers'; 

const firebaseConfig = {
  apiKey: "AIzaSyAFtoUdyc-HMagB1PG0ruBLa305LsRrjqQ",
  authDomain: "reactclientmanager-a6a7f.firebaseapp.com",
  databaseURL: "https://reactclientmanager-a6a7f.firebaseio.com",
  projectId: "reactclientmanager-a6a7f",
  storageBucket: "reactclientmanager-a6a7f.appspot.com",
  messagingSenderId: "236695323234"
};

//react-redux-firebase config
const rrfConfig = {
  userProfile: 'users',
  useFirestoreForProfile: true // Firestore for Profile instead of Realtime DB
}

//Init firebase instance
firebase.initializeApp(firebaseConfig);

//Init firestore
const firestore = firebase.firestore();


// Add reactReduxFirebase enhancer when making store creator
const createStoreWithFirebase = compose(
  reactReduxFirebase(firebase, rrfConfig), // firebase instance as first argument
  reduxFirestore(firebase) // <- needed if using firestore
)(createStore)

const rootReducer = combineReducers({
  firebase: firebaseReducer,
  firestore: firestoreReducer, // <- needed if using firestore
  notify: notifyReducer,
  settings: settingsReducers
})

//check for settings in local storage
if(localStorage.getItem('settings') == null){
  //default settings

  const defaultSettings = {
    disableBalanceOnAdd: true,
    disableBalanceOnEdit: false,
    allowRegistration: false
  };
  //set to local storage
  localStorage.setItem('settings', JSON.stringify(defaultSettings));
}

//Create initial state
const initialState = {settings: JSON.parse(localStorage.getItem('settings'))};


// Create store
const store = createStoreWithFirebase(
  rootReducer,
  initialState,
  composeWithDevTools(
  reactReduxFirebase(firebase)
));

export default store;