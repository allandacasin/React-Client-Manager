import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import { compose } from 'redux';
import { connect } from 'react-redux';
import { firestoreConnect } from 'react-redux-firebase';
import Spinner from '../layout/Spinner';


class EditClient extends React.Component {
  constructor(props) {
    super(props);
  
    this.firstNameInput = React.createRef();
    this.lastNameInput = React.createRef();
    this.emailInput = React.createRef();
    this.phoneInput = React.createRef();
    this.streetAddressInput = React.createRef();
    this.stateOrCountyInput = React.createRef();
    this.townOrCityInput = React.createRef();
    this.postCodeInput = React.createRef();
    this.balanceInput = React.createRef();
  }

  onSubmit = e => {
    e.preventDefault();

    const {client, firestore, history} = this.props;

    //update client
    const updateClient = {
      firstName: this.firstNameInput.current.value,
      lastName: this.lastNameInput.current.value,
      email: this.emailInput.current.value,
      phone: this.phoneInput.current.value,
      streetAddress: this.streetAddressInput.current.value,
      townOrCity: this.townOrCityInput.current.value,
      stateOrCounty: this.stateOrCountyInput.current.value,
      postCode: this.postCodeInput.current.value,
      balance: this.balanceInput.current.value === '' ? 0: this.balanceInput.current.value
    }

    //update client in firestore
    firestore.update({collection: 'clients', doc: client.id}, updateClient)
      .then(history.push('/'));

  } 

  render() {
    const { client } = this.props;
    const {disableBalanceOnEdit} = this.props.settings;

    if (client) {
      return (
        <div>
          <div className="row">
          <div className="col-md-6">
            <Link to="/" className="btn btn-link">
             <i className="fas fa-arrow-circle-left"></i> Back To Dashboard
            </Link>
          </div>
        </div>
        <div className="card">
          <div className="card-header">Edit Client</div>
            <div className="card-body">
              <form onSubmit={this.onSubmit}>
                <div className="form-group" >
                  <label htmlFor="firstName">First Name</label>
                  <input type="text" className="form-control" name="firstName" ref={this.firstNameInput} minLength="2" required defaultValue={client.firstName} />
                </div>
                <div className="form-group" >
                  <label htmlFor="lastName">Last Name</label>
                  <input type="text" className="form-control" name="lastName" ref={this.lastNameInput} minLength="2" required defaultValue={client.lastName} />
                </div>
                <div className="form-group" >
                  <label htmlFor="phone">Phone</label>
                  <input type="text" className="form-control" name="phone" ref={this.phoneInput} minLength="2" defaultValue={client.phone} />
                </div>
                <div className="form-group" >
                  <label htmlFor="email">Email</label>
                  <input type="email" className="form-control" name="email" ref={this.emailInput} minLength="2" required defaultValue={client.email} />
                </div>
                <div className="form-group" >
                  <label htmlFor="text">Street Address</label>
                <input type="text" className="form-control" name="streetAddress" ref={this.streetAddressInput} minLength="2" required defaultValue={client.streetAddress} />                
                </div>
                <div className="form-group" >
                  <label htmlFor="text">City</label>
                  <input type="text" className="form-control" name="townOrCity" ref={this.townOrCityInput} minLength="2" required defaultValue={client.townOrCity} />                
                </div>
                <div className="form-group" >
                  <label htmlFor="text">State or Province</label>
                  <input type="text" className="form-control" name="stateOrCounty" ref={this.stateOrCountyInput} minLength="2" required defaultValue={client.stateOrCounty} />                
                </div>
                <div className="form-group" >
                  <label htmlFor="text">Post Code</label>
                  <input type="text" className="form-control" name="postCode" ref={this.postCodeInput} minLength="2" required defaultValue={client.postCode} />                
                </div>
                <div className="form-group" >
                  <label htmlFor="balance">Balance</label>
                  <input type="number" className="form-control" name="balance" ref={this.balanceInput} required defaultValue={client.balance} disabled={disableBalanceOnEdit} />
                </div>
                <input type="submit" value="Submit" className="btn btn-primary btn-small btn-block" />
              </form>
            </div>
          </div>
        </div>);
    } else {
      return <Spinner />;
    }
  }
}

EditClient.propTypes = {
  firestore: PropTypes.object.isRequired,
  settings: PropTypes.object.isRequired
};

export default compose(
  firestoreConnect(props => [
    { collection: "clients", storeAs: "client", doc: props.match.params.id }
  ]),
  connect(({ firestore: { ordered } }, props) => ({
    client: ordered.client && ordered.client[0],
  })),
  connect((state, props) => ({
    settings: state.settings
  }))
)(EditClient);
