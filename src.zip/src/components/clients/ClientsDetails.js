import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import { compose } from 'redux';
import { connect } from 'react-redux';
import { firestoreConnect } from 'react-redux-firebase';
import Spinner from '../layout/Spinner';


class ClientsDetails extends React.Component {
  state = {
    showBalanceUpdate: false,
    balanceUpdateAmount: ''
  };

  //update balance
  balanceSubmit = e => {
    e.preventDefault();

    const { client, firestore } = this.props;
    const { balanceUpdateAmount } = this.state;

    const clientUpdate = {
      balance: parseFloat(balanceUpdateAmount)
    }

    //Update in firestore
    firestore.update({collection: 'clients', doc: client.id}, clientUpdate)

  };

  //delete client
  onDeleteClick = () => {
    const { client, firestore, history } = this.props;
    firestore.delete({collection: 'clients', doc: client.id})
    .then(history.push('/'))
  }

  onChange = e => this.setState({[e.target.name]: e.target.value});

  render() {
    const { client } = this.props;
    const { showBalanceUpdate, balanceUpdateAmount } = this.state;

    let balanceForm = '';

    if(showBalanceUpdate) {
      balanceForm = (
        <form onSubmit={this.balanceSubmit}>
          <div className="input-group small">
            <input
              type="number" 
              className="form-control" 
              name="balanceUpdateAmount" 
              placeholder="Add New Balance"
              required
              value={balanceUpdateAmount}
              onChange={this.onChange}
            />
            <div className="input-group-append">
              <input type="submit" value="Update" className="btn btn-primary btn-sm" />
            </div>
          </div>
        </form>
      )
    } else {
      balanceForm = null;
    }

    if (client) {
      return (
      <div>
        <div className="row">
          <div className="col-md-6">
            <Link to="/" className="btn btn-link btn-small">
              <i className="fas fa-arrow-circle-left"></i> Back To Dashboard
            </Link>
          </div>
          <div className="col-md-6">
            <div className="btn-group float-right">
              <Link to={`/client/edit/${client.id}`}>
                <i className="far fa-edit fa-2x mr-1"></i>
              </Link>
              <a href="#">
                <i onClick={this.onDeleteClick} className="far fa-trash-alt text-danger fa-2x"></i>
              </a>
            </div>
          </div>
        </div>
        <hr />
        <div className="card">
          <h5 className="card-header">
            {client.firstName} {client.lastName}
          </h5>
          <div className="card-body">
            <div className="row">
              <div className="col-md-8 col-sm-6>">
                Client ID: {''} <span className="text-secondary">{client.id}</span>
              </div>
              <div className="col-md-4 col-sm-6>">
                Balance: <span className={client.balance === 0 ? 'text-success' : 'text-danger'}>{parseFloat(client.balance).toFixed(2)} NOK</span>
                <small>
                  <a href="#!" onClick={ () => this.setState({showBalanceUpdate: !this.state.showBalanceUpdate})}><i className="fas fa-pencil-alt ml-3"></i></a>
                </small>
                {balanceForm}
              </div>
            </div>
            <hr />
            <ul className="list-group">
              <li className="list-group-item">Contact Email: {client.email}</li>
              <li className="list-group-item">Contact Phone: {client.phone}</li>
              <li className="list-group-item">Address: {client.streetAddress} {client.townOrCity}, {client.stateOrCounty} {client.postCode}</li>
            </ul>
          </div>
        </div>
      </div>
      )

    } else {
      return <Spinner />
    }

  }
}

ClientsDetails.propTypes = {
  firestore: PropTypes.object.isRequired,
}

export default compose(
  firestoreConnect(props => [
    {collection: 'clients', storeAs: 'client', doc: props.match.params.id}
  ]),
  connect(({firestore:{ ordered }}, props) => ({
    client: ordered.client && ordered.client[0]
  }))
)(ClientsDetails);
