import React from 'react';
import {Link} from 'react-router-dom';

export default class Sidebar extends React.Component {

  render() {
    return (
      <Link to="/client/add" className="btn btn-success btn-sm btn-block">
        <i className="fa fa-plus"></i> Add Client
      </Link>
    );
  }
}
